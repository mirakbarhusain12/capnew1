package stepdef;

import static io.restassured.RestAssured.when;
import static org.hamcrest.Matchers.equalTo;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.when;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.equalTo;
 import java.util.Map;
 import org.apache.commons.lang3.StringUtils;
 import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.matcher.ResponseAwareMatcher;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class NewTest 
{
 
        private  Response response;
		private	ValidatableResponse json;
		private	RequestSpecification request ;
	  @Test
	  public void f() 
	    {
		
		  response =when().get("http://restapi.demoqa.com/utilities/weather/city/mysore");
			//System.out.println("response: " + response.prettyPrint());
			int statusCode=200;
			int statusCode1 = response.getStatusCode();
	 		json = response.then().statusCode(statusCode);
	 		//System.out.println(json);
	 		System.out.println(response.then().statusCode(200));
			System.out.println("response: " + response.prettyPrint());
			ResponseBody body=response.getBody();
			String bodyAsString = body.asString();
		   when().get("http://restapi.demoqa.com/utilities/weather/city/mysore").then().assertThat().statusCode(200);
	   when().get("http://restapi.demoqa.com/utilities/weather/city/mysore").then().assertThat().body("City",equalTo("Mysore"));
		System.out.println("welcome akbar");
		
		JsonPath jsonPathEvaluator = response.jsonPath();
	    String city = jsonPathEvaluator.get("City");
	    System.out.println("status code= " + statusCode1);
	    System.out.println("City= " + city);

	  //response.get().then().assertThat().body("MRData.DriverTable.Drivers.driverId", hasItem(driver));
		
		//	Assert.assertEquals(bodyAsString.contains("Hyderabad") /*Expected value*/, true /*Actual Value*/, "Response body contains Hyderabad");


	  

	  }

  }

