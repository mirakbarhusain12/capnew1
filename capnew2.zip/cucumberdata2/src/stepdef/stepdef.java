package stepdef;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;		
import cucumber.api.java.en.Then;		
import cucumber.api.java.en.When;		
public class stepdef 
{				
 	WebDriver d ;
 	
 	//@Before
    //@Before("@akbar1 and @akbar31")
 	@Before
    public void beforeScenario()
 	{
 		 
 		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver.exe");
  	   d=new ChromeDriver();
    } 
 
    @Given("^Open ksrtc web site$")				
    public void Open_ksrtc_web_site() throws Throwable							
    {	
    	//System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver.exe");
    	 // d=new ChromeDriver();
        d.get("http://www.ksrtc.in/oprs-web/");
        d.manage().window().maximize();
        //Thread.sleep(10000);
        //throw new PendingException();
     }		

    @When("user inputs Username and Password$")					
    public void user_inputs_Username_and_Password() throws Throwable 							
    {		
    	d.findElement(By.linkText("Sign In")).click();

  		Thread.sleep(2000);
  		d.findElement(By.xpath("//*[@id='userName']")).sendKeys("mah@yahoo.com");
  		d.findElement(By.xpath("//*[@id='password']")).sendKeys("mysore15");
  		d.findElement(By.xpath("//*[@id='submitBtn']")).click();
        //throw new PendingException();

    }		

    @Then("^Login should be successfull$")					
    public void Login_should_be_successfull() throws Throwable 							
    {    		
    	 boolean a=d.findElement(By.linkText("Logout")).isDisplayed();
		    if(a) 
		    {
		        System.out.println("login success  No defect");

		    }
		    else
		    {
		        System.out.println("login not success  A defect");
		    }
	      //throw new PendingException();

	 }		
    //--------------------------------------------------------
    @Given("^user clicks the link PNR Enquiry$")
    public void user_clicks_the_link_boom_a_bus() throws Throwable 
    {
    	d.findElement(By.linkText("PNR Enquiry")).click();
       //throw new PendingException();
    }

   

    @Then("^user should see a module$")
    public void user_should_see_a_module() throws Throwable 
    {
    	if(d.getPageSource().contains("PNR Enquiry"))
   	   {
   	        System.out.println("on clicking the PNR enquiry link module appeared- No defect");
   	   
   	   }
   	   else
   	   {
   	        System.out.println("on clicking the PNR enquiry link the module did not appear- A defect");
   	   
   	   }
  		//	throw new PendingException();
    }
 

    @Then("^user should see a  Welcome to KSRTC$")
    public void user_should_see_a_module_for_cancelling_tickets() throws Throwable 
    {
    	Thread.sleep(5000);
    	 if(d.getPageSource().contains("Welcome to KSRTC"))
  	   {
  	        System.out.println("the text Welcome to KSRTC is present - No defect");
  	   
  	   }
  	   else
  	   {
  	        System.out.println("the text welcome to ksrtc is not present- A defect");
  	   
  	   }
    	
    	
    	//throw new PendingException();
    }
   
	


    @After("@akbar1, @akbar31")
    public void afterScenario1()
    {
        d.quit();
    }
	
	 
    @After(order=2)
	public void afterScenario()
	{
	    System.out.println("ckheked for pnr enquiry");
	}
    @After(order=3)
   	public void afterScenario2()
   	{
	    System.out.println("ckheked for text prescence");
   	}
    //-------------------------------------------------------
    

}