package runner;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;
import cucumber.api.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions(
		     features={"C:\\Users\\Admin\\eclipse-workspace\\madhu1\\cucumberdata2\\scenario-feature\\a.Feature"}
             ,glue="stepdef"
             //,plugin = {"pretty", "html:target/akbar-report"}
       		 //,plugin = { "pretty", "junit:target/akbar-report.xml" }
             ,monochrome = true
		    ,plugin={"json:target/akbar.json"}
             // ,dryRun = true
             // ,strict = true
             ,tags = {"@akbar1" ,"~@akbar31"} 
             //,tags = {"@akbar1,@akbar31"} or
            // ,tags = {"@akbar1" ,"@akbar31"} //and
              //,tags = {"@SmokeTest , @sa"}

              )      
public class ru 
{    

}

 
