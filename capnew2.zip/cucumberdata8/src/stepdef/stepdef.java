package stepdef;
import java.io.File;
import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;		
import cucumber.api.java.en.Then;		
import cucumber.api.java.en.When;		
public class stepdef 
{				
 	WebDriver d ;
    @Given("^Open first paris bank site$")				
    public void Openfirstparisbanksite() throws Throwable							
    {	
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver.exe");
    	d=new ChromeDriver();
        d.get("https://www.firstparis.net");
        d.manage().window().maximize();
         //throw new PendingException();
     }		
   @When("^user selects search item from \"(.*)\" module should appear$")
    public void userinputsearchitem(String filepath) throws Throwable 							
    {		
    	File file=new File(filepath);
        FileInputStream fi=new FileInputStream(file);
        //String fn="C:\\Users\\Admin\\Desktop\\Data.xlsx";
        System.out.println(filepath);
        System.out.println("welcome");

        //Find the file extension by splitting file name in substring  and getting only extension name
        String fe=filepath.substring(filepath.indexOf("."));
        System.out.println(fe);
        try
        {
             if(fe.equals(".xlsx"))
           {
               System.out.println("your file extension is xlsx");
              @SuppressWarnings("resource")
			Workbook w = new XSSFWorkbook(fi);
              Sheet guru99Sheet = w.getSheet("s");
              System.out.println("welcome akbar");

              int rowCount = guru99Sheet.getLastRowNum()-guru99Sheet.getFirstRowNum();
              for (int i = 0; i < rowCount+1; i++) 
              {
                  Row row = guru99Sheet.getRow(i);
                  String name=null;
           	   String password=null;
                  for (int j = 0; j < row.getLastCellNum(); j++) 
                  {
                        if(j==0)
                	  {
      
                     	name=row.getCell(j).getStringCellValue();

                	  }
                	if(j==1)
                	{
                	 password=row.getCell(j).getStringCellValue();
                	}
                  }  
   
                  System.out.print(name);
                  
                     Thread.sleep(3000);
                     d.findElement(By.id("query")).sendKeys(name);
                      d.findElement(By.id("search-submit")).submit();
                     d.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
                    if(name.equalsIgnoreCase("savings"))
             	     {
              	        System.out.println("\n");
                    	 if(d.getPageSource().contains("savings")) 
                 	    {
                 	        System.out.println("search functionallity is displaying respective savings module-No defect");
                         }
                 	    else
                 	    {
                 	        System.out.println("search functionallity is not displaying respective savings module-A defect");
                         } 
                      }
                     
                     if(name.equalsIgnoreCase("current"))
             	     {
              	        System.out.println("\n");
                    	 if(d.getPageSource().contains("current")) 
                 	    {
                 	        System.out.println("search functionallity is displaying respective current module-No defect");
                         }
                 	    else
                 	    {
                 	        System.out.println("search functionallity is not displaying respective current module-A defect");
                         } 
                      }     
  }       
              }
           }
      //for ends------------------------------------------------------------         
   catch (Exception e)
          {
       		throw (e);
          }
  //throw new PendingException();
    }		
/**
    @Then("^Login should be successfull$")					
    public void Login_should_be_successfull() throws Throwable 							
    {    		
    	 boolean a=d.findElement(By.linkText("Logout")).isDisplayed();
		    if(a) 
		    {
		        System.out.println("login success for valid name  and valid password-No defect");

		    }
		    else
		    {
		        System.out.println("login not success for valid name  and valid password-A defect");
		    }
	      //throw new PendingException();

	 }	
  */  
}