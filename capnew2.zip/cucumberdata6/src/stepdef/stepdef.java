package stepdef;
import static io.restassured.RestAssured.when;
import static org.hamcrest.Matchers.equalTo;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;		
import cucumber.api.java.en.Then;		
import cucumber.api.java.en.When;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBodyExtractionOptions;
import io.restassured.response.ResponseOptions;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;		
public class stepdef 
{				
	private  ValidatableResponse response;
	private	ValidatableResponse json;
	private	RequestSpecification request ;
     @Given("^the weather api is available on web server$")				
    public void Open_ksrtc_web_site() throws Throwable							
    {	
    	 response= request.get("http://restapi.demoqa.com/utilities/weather/city/mysore").then().assertThat().statusCode(200);        //throw new PendingException();
     }		
    @When("performed Get request to that API$")					
    public void user_inputs_Username_and_Password() throws Throwable 							
    {		
   	 response= request.get("http://restapi.demoqa.com/utilities/weather/city/mysore").then().assertThat().statusCode(200);        //throw new PendingException();
    }		
    @Then("^expect the below$")					
    public void Login_should_be_successfull() throws Throwable 							
    {    		
      int statusCode1 = ((ResponseOptions<Response>) response).getStatusCode();	
      request.when().get("http://restapi.demoqa.com/utilities/weather/city/mysore").then().assertThat().body("City",equalTo("Mysore"));
      JsonPath jsonPathEvaluator = ((ResponseBodyExtractionOptions) response).jsonPath();
      String city = jsonPathEvaluator.get("City");
      System.out.println("status code= " + statusCode1);
      System.out.println("City= " + city);
	 }		
   // when().get("http://restapi.demoqa.com/utilities/weather/city/mysore").then().assertThat().body("City",equalTo("Mysore"));


}