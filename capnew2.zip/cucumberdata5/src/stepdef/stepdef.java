package stepdef;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.eclipse.jetty.client.api.Response;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.util.StringUtils;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;		
import cucumber.api.java.en.Then;		
import cucumber.api.java.en.When;
import io.restassured.matcher.ResponseAwareMatcher;
import io.restassured.response.ResponseBody;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;		
public class stepdef 
{

	private io.restassured.response.Response response;
	private ValidatableResponse json;
	private RequestSpecification request;
	public String ENDPOINT_GET_BOOK_BY_ISBN = "http://apilayer.net/api/validate?access_key=1174a746417931b473d440f1c9f824d7&number=9731310981&country_code=IN&format=2";
   @When("^a user retrieves the book by isbn$")
	public void a_user_retrieves_the_book_by_isbn()
   {
		response = request.when().get("http://apilayer.net/api/validate?access_key=1174a746417931b473d440f1c9f824d7&number=9731310981&country_code=IN&format=2");
		System.out.println("response: " + ((ResponseBody<io.restassured.response.Response>) response).prettyPrint());
	}

}
