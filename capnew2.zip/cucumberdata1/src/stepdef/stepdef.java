package stepdef;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;		
import cucumber.api.java.en.Then;		
import cucumber.api.java.en.When;		
public class stepdef 
{				
 	WebDriver d ;
    @Given("^Open ksrtc web site$")				
    public void Open_ksrtc_web_site() throws Throwable							
    {	
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver.exe");
    	  d=new ChromeDriver();
        d.get("http://www.ksrtc.in/oprs-web/");
        d.manage().window().maximize();
        //d.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        //Thread.sleep(10000);
        //throw new PendingException();
     }		
   // @When("user inputs Username and Password$")					
   // @When(�^User inputs \�(.*)\� and \�(.*)\�$�)
    //When user inputs "mah@yahoo.com" and "mysore15"			

    //When user inputs "mah@yahoo.com" and "mysore15"			

   // @When("^user inputs \"(.*)\" and \"(.*)\"$")	
    //@When("^User inputs \"(.*)\" and \"(.*)\"$")
    //@When("^User inputs \".*\" and \".*\"$")
    //@When("^User inputs \"(.*)\" and \"(.*)\"$")
   // When user inputs "mah@yahoo.com"			
   // When user inputs "mah@yahoo.com"
    //@When("^User inputs "(.*)" and "(.*"$")
    
    @When("^user input name \\\"(.*)\\\"$")
    public void userinputsusername(String name) throws Throwable 							
    {		
     	d.findElement(By.linkText("Sign In")).click();
  		Thread.sleep(2000);
  		d.findElement(By.xpath("//*[@id='userName']")).sendKeys(name);
  	    //throw new PendingException();
    }		
    @And("^user input password \\\"(.*)\\\"$")
    public void userinputPassword(String password) throws Throwable 							
    {		
    	d.findElement(By.xpath("//*[@id='password']")).sendKeys(password);
  		d.findElement(By.xpath("//*[@id='submitBtn']")).click();
        //throw new PendingException();
    }		
 @Then("^Login should be successfull$")					
    public void Login_should_be_successfull() throws Throwable 							
    {    		
    	 boolean a=d.findElement(By.linkText("Logout")).isDisplayed();
		    if(a) 
		    {
		        System.out.println("login success for valid name  and valid password No defect");

		    }
		    else
		    {
		        System.out.println("login not success for valid name  and valid password A defect");
		    }
	      //throw new PendingException();

	 }		

}